from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.user_generator import UserGenerator
from app.generators.product_generator import ProductGenerator
from app.generators.order_generator import OrderGenerator
from app.generators.engagement_generator import EngagementGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/notifications", ["Notifications"])

@router.get("/", summary="Generate notification data")
async def get_notifications(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock notification data with the following fields:
    - notification_id: UUID
    - user_id: Foreign key to user
    - type: Notification type
    - title: Notification title
    - message: Notification message
    - created_at: Notification creation timestamp
    - read: Whether notification has been read
    - read_at: When notification was read
    - order_id: Related order ID (if applicable)
    - product_id: Related product ID (if applicable)
    - action_url: Action URL
    - icon: Notification icon
    - priority: Notification priority (low, normal, high)
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate users, products, and orders first
    engagement_generator = EngagementGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not engagement_generator.user_ids:
        user_generator = UserGenerator(seed=format_params.seed)
        users = user_generator.generate_users(limit=format_params.limit // 2)
        engagement_generator.user_ids = [u["user_id"] for u in users]
    
    if not engagement_generator.product_ids:
        product_generator = ProductGenerator(seed=format_params.seed)
        products = product_generator.generate_products(limit=format_params.limit)
        engagement_generator.product_ids = [p["product_id"] for p in products]
        
    if not engagement_generator.order_ids:
        order_generator = OrderGenerator(seed=format_params.seed)
        order_generator.user_ids = engagement_generator.user_ids
        order_generator.product_ids = engagement_generator.product_ids
        orders = order_generator.generate_orders(limit=format_params.limit // 2)
        engagement_generator.order_ids = [o["order_id"] for o in orders]
    
    notifications = engagement_generator.generate_notifications(limit=format_params.limit)
    
    return create_response(
        engagement_generator,
        notifications,
        format_params,
        root_name="notifications",
        item_name="notification"
    )