from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.user_generator import UserGenerator
from app.generators.product_generator import ProductGenerator
from app.generators.order_generator import OrderGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/orders", ["Orders"])

@router.get("/", summary="Generate order data")
async def get_orders(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock order data with the following fields:
    - order_id: UUID
    - user_id: Foreign key to user
    - status: Order status (pending, processing, shipped, delivered, cancelled)
    - created_at: Order creation timestamp
    - updated_at: Last order update timestamp
    - shipping_address: Shipping address
    - shipping_city: Shipping city
    - shipping_state: Shipping state
    - shipping_postal_code: Shipping postal/ZIP code
    - shipping_country: Shipping country
    - shipping_method: Shipping method
    - shipping_cost: Shipping cost
    - subtotal: Order subtotal
    - tax: Tax amount
    - discount: Discount amount
    - total: Order total
    - coupon_code: Applied coupon code
    - notes: Order notes
    - tracking_number: Shipping tracking number
    - estimated_delivery: Estimated delivery date
    - actual_delivery: Actual delivery date
    - payment_id: Foreign key to payment
    - items: Array of order items with product details
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate users and products first for relational integrity
    generator = OrderGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not generator.user_ids:
        user_generator = UserGenerator(seed=format_params.seed)
        users = user_generator.generate_users(limit=format_params.limit // 2)
        generator.user_ids = [u["user_id"] for u in users]
    
    if not generator.product_ids:
        product_generator = ProductGenerator(seed=format_params.seed)
        products = product_generator.generate_products(limit=format_params.limit)
        generator.product_ids = [p["product_id"] for p in products]
    
    orders = generator.generate_orders(limit=format_params.limit)
    
    return create_response(
        generator,
        orders,
        format_params,
        root_name="orders",
        item_name="order"
    )