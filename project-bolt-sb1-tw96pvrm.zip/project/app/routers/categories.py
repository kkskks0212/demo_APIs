from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.product_generator import ProductGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/categories", ["Categories"])

@router.get("/", summary="Generate product category data")
async def get_categories(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock product category data with the following fields:
    - category_id: UUID
    - name: Category name
    - description: Category description
    - parent_id: Foreign key to parent category (null for top-level)
    - level: Category level (1 for main, 2 for sub, etc.)
    - created_at: Category creation timestamp
    - updated_at: Last category update timestamp
    - is_active: Whether the category is active
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate (will be adjusted for categories)
    - seed: Random seed for reproducible data
    """
    generator = ProductGenerator(seed=format_params.seed)
    categories = generator.generate_categories()
    
    return create_response(
        generator,
        categories,
        format_params,
        root_name="categories",
        item_name="category"
    )