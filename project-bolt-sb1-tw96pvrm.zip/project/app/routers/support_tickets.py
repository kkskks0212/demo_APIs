from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.user_generator import UserGenerator
from app.generators.order_generator import OrderGenerator
from app.generators.engagement_generator import EngagementGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/support-tickets", ["Support"])

@router.get("/", summary="Generate support ticket data")
async def get_tickets(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock support ticket data with the following fields:
    - ticket_id: UUID
    - user_id: Foreign key to user
    - order_id: Foreign key to order (if applicable)
    - subject: Ticket subject
    - description: Ticket description
    - type: Ticket type (question, issue, complaint, etc.)
    - priority: Ticket priority (low, medium, high, urgent)
    - status: Ticket status (new, in_progress, waiting_for_customer, resolved, closed)
    - created_at: Ticket creation timestamp
    - updated_at: Last ticket update timestamp
    - resolved_at: Resolution timestamp
    - closed_at: Closed timestamp
    - assigned_to: Assigned staff name
    - first_response_time: First response time in hours
    - resolution_time: Resolution time in hours
    - satisfaction_rating: Customer satisfaction rating (1-5)
    - tags: Array of ticket tags
    - channel: Support channel (email, phone, chat, social_media, website)
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate users and orders first
    engagement_generator = EngagementGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not engagement_generator.user_ids:
        user_generator = UserGenerator(seed=format_params.seed)
        users = user_generator.generate_users(limit=format_params.limit // 2)
        engagement_generator.user_ids = [u["user_id"] for u in users]
        
    if not engagement_generator.order_ids:
        order_generator = OrderGenerator(seed=format_params.seed)
        order_generator.user_ids = engagement_generator.user_ids
        
        if not order_generator.product_ids:
            # Need products for orders
            from app.generators.product_generator import ProductGenerator
            product_generator = ProductGenerator(seed=format_params.seed)
            products = product_generator.generate_products(limit=format_params.limit)
            order_generator.product_ids = [p["product_id"] for p in products]
        
        orders = order_generator.generate_orders(limit=format_params.limit // 2)
        engagement_generator.order_ids = [o["order_id"] for o in orders]
    
    tickets = engagement_generator.generate_support_tickets(limit=format_params.limit)
    
    return create_response(
        engagement_generator,
        tickets,
        format_params,
        root_name="support_tickets",
        item_name="ticket"
    )