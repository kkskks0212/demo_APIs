from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.product_generator import ProductGenerator
from app.generators.logistics_generator import LogisticsGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/inventory", ["Inventory"])

@router.get("/", summary="Generate inventory data")
async def get_inventory(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock inventory data with the following fields:
    - inventory_id: UUID
    - product_id: Foreign key to product
    - warehouse_id: Foreign key to warehouse
    - quantity: Current quantity in stock
    - min_stock_level: Minimum stock level
    - max_stock_level: Maximum stock level
    - shelf_location: Warehouse shelf location
    - created_at: Record creation timestamp
    - updated_at: Last record update timestamp
    - last_restock_date: Last restock date
    - next_restock_date: Next scheduled restock date
    - is_in_stock: Whether item is in stock
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate products and warehouses first
    logistics_generator = LogisticsGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not logistics_generator.product_ids:
        product_generator = ProductGenerator(seed=format_params.seed)
        products = product_generator.generate_products(limit=format_params.limit)
        logistics_generator.product_ids = [p["product_id"] for p in products]
    
    if not logistics_generator.warehouse_ids:
        warehouses = logistics_generator.generate_warehouses()
    
    inventory = logistics_generator.generate_inventory(limit=format_params.limit)
    
    return create_response(
        logistics_generator,
        inventory,
        format_params,
        root_name="inventory",
        item_name="inventory_record"
    )