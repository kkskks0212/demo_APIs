from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.user_generator import UserGenerator
from app.generators.product_generator import ProductGenerator
from app.generators.analytics_generator import AnalyticsGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/analytics", ["Analytics"])

@router.get("/users", summary="Generate user analytics data")
async def get_user_analytics(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock user analytics data with the following fields:
    - analytics_id: UUID
    - user_id: Foreign key to user
    - date: Analytics date
    - sessions: Number of sessions
    - total_session_time: Total session time in seconds
    - avg_session_time: Average session time in seconds
    - pages_viewed: Number of pages viewed
    - device_type: Device type (mobile, desktop, tablet)
    - platform: Platform (web, ios, android)
    - referral_source: Referral source
    - cart_adds: Number of cart additions
    - cart_abandons: Number of cart abandonments
    - purchases: Number of purchases
    - cart_add_rate: Cart addition rate
    - conversion_rate: Conversion rate
    - created_at: Record creation timestamp
    - location: Location object with country, city, region
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate users first
    analytics_generator = AnalyticsGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not analytics_generator.user_ids:
        user_generator = UserGenerator(seed=format_params.seed)
        users = user_generator.generate_users(limit=format_params.limit // 2)
        analytics_generator.user_ids = [u["user_id"] for u in users]
    
    user_analytics = analytics_generator.generate_user_analytics(limit=format_params.limit)
    
    return create_response(
        analytics_generator,
        user_analytics,
        format_params,
        root_name="user_analytics",
        item_name="analytics"
    )

@router.get("/products", summary="Generate product analytics data")
async def get_product_analytics(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock product analytics data with the following fields:
    - analytics_id: UUID
    - product_id: Foreign key to product
    - date: Analytics date
    - views: Number of views
    - unique_views: Number of unique views
    - add_to_cart_count: Number of times added to cart
    - add_to_wishlist_count: Number of times added to wishlist
    - purchase_count: Number of purchases
    - units_sold: Number of units sold
    - cart_add_rate: Cart addition rate
    - purchase_rate: Purchase rate
    - avg_price: Average price
    - revenue: Total revenue
    - created_at: Record creation timestamp
    - referral_sources: Referral sources breakdown
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate products first
    analytics_generator = AnalyticsGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not analytics_generator.product_ids:
        product_generator = ProductGenerator(seed=format_params.seed)
        products = product_generator.generate_products(limit=format_params.limit)
        analytics_generator.product_ids = [p["product_id"] for p in products]
    
    product_analytics = analytics_generator.generate_product_analytics(limit=format_params.limit)
    
    return create_response(
        analytics_generator,
        product_analytics,
        format_params,
        root_name="product_analytics",
        item_name="analytics"
    )