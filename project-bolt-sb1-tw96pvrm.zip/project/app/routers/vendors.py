from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.product_generator import ProductGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/vendors", ["Vendors"])

@router.get("/", summary="Generate vendor data")
async def get_vendors(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock vendor data with the following fields:
    - vendor_id: UUID
    - name: Vendor company name
    - description: Vendor description
    - contact_name: Contact person name
    - contact_email: Contact email
    - contact_phone: Contact phone number
    - address: Vendor address
    - city: City
    - state: State
    - postal_code: Postal/ZIP code
    - country: Country
    - website: Vendor website
    - created_at: Vendor creation timestamp
    - updated_at: Last vendor update timestamp
    - rating: Vendor rating (1-5)
    - is_active: Whether the vendor is active
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    generator = ProductGenerator(seed=format_params.seed)
    vendors = generator.generate_vendors(limit=format_params.limit)
    
    return create_response(
        generator,
        vendors,
        format_params,
        root_name="vendors",
        item_name="vendor"
    )