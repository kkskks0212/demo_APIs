from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.user_generator import UserGenerator
from app.generators.product_generator import ProductGenerator
from app.generators.order_generator import OrderGenerator
from app.generators.engagement_generator import EngagementGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/reviews", ["Reviews"])

@router.get("/", summary="Generate product review data")
async def get_reviews(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock product review data with the following fields:
    - review_id: UUID
    - product_id: Foreign key to product
    - user_id: Foreign key to user
    - order_id: Foreign key to order
    - rating: Rating (1-5)
    - title: Review title
    - content: Review content
    - created_at: Review creation timestamp
    - updated_at: Last review update timestamp
    - helpful_votes: Number of helpful votes
    - verified_purchase: Whether review is from verified purchase
    - images: Array of review image URLs
    - is_featured: Whether review is featured
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate users, products, and orders first
    engagement_generator = EngagementGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not engagement_generator.user_ids:
        user_generator = UserGenerator(seed=format_params.seed)
        users = user_generator.generate_users(limit=format_params.limit // 2)
        engagement_generator.user_ids = [u["user_id"] for u in users]
    
    if not engagement_generator.product_ids:
        product_generator = ProductGenerator(seed=format_params.seed)
        products = product_generator.generate_products(limit=format_params.limit)
        engagement_generator.product_ids = [p["product_id"] for p in products]
        
    if not engagement_generator.order_ids:
        order_generator = OrderGenerator(seed=format_params.seed)
        order_generator.user_ids = engagement_generator.user_ids
        order_generator.product_ids = engagement_generator.product_ids
        orders = order_generator.generate_orders(limit=format_params.limit // 2)
        engagement_generator.order_ids = [o["order_id"] for o in orders]
    
    reviews = engagement_generator.generate_reviews(limit=format_params.limit)
    
    return create_response(
        engagement_generator,
        reviews,
        format_params,
        root_name="reviews",
        item_name="review"
    )