from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.user_generator import UserGenerator
from app.generators.product_generator import ProductGenerator
from app.generators.payment_generator import PaymentGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/subscriptions", ["Subscriptions"])

@router.get("/", summary="Generate subscription data")
async def get_subscriptions(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock subscription data with the following fields:
    - subscription_id: UUID
    - user_id: Foreign key to user
    - plan: Subscription plan (monthly, quarterly, annual)
    - status: Subscription status (active, cancelled, paused, past_due)
    - amount: Subscription amount
    - currency: Currency code
    - start_date: Subscription start date
    - next_billing_date: Next billing date
    - end_date: Subscription end date
    - payment_method: Payment method (credit_card, paypal)
    - auto_renew: Whether subscription auto-renews
    - products: Array of product IDs included in subscription
    - created_at: Subscription creation timestamp
    - updated_at: Last subscription update timestamp
    - last_payment_date: Last payment date
    - total_payments: Total number of payments made
    - discount_percent: Subscription discount percentage
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate users and products first for relational integrity
    payment_generator = PaymentGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not payment_generator.user_ids:
        user_generator = UserGenerator(seed=format_params.seed)
        users = user_generator.generate_users(limit=format_params.limit // 2)
        payment_generator.user_ids = [u["user_id"] for u in users]
    
    if not payment_generator.product_ids:
        product_generator = ProductGenerator(seed=format_params.seed)
        products = product_generator.generate_products(limit=format_params.limit)
        payment_generator.product_ids = [p["product_id"] for p in products]
    
    subscriptions = payment_generator.generate_subscriptions(limit=format_params.limit)
    
    return create_response(
        payment_generator,
        subscriptions,
        format_params,
        root_name="subscriptions",
        item_name="subscription"
    )