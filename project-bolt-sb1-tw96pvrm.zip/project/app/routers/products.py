from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.product_generator import ProductGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/products", ["Products"])

@router.get("/", summary="Generate product data")
async def get_products(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock product data with the following fields:
    - product_id: UUID
    - name: Product name
    - description: Product description
    - sku: Stock keeping unit
    - price: Product price
    - cost: Product cost
    - weight: Product weight
    - dimensions: Product dimensions
    - category_id: Foreign key to category
    - vendor_id: Foreign key to vendor
    - created_at: Product creation timestamp
    - updated_at: Last product update timestamp
    - is_active: Whether the product is active
    - stock_quantity: Number of units in stock
    - tags: Array of product tags
    - image_url: Product image URL
    - average_rating: Average product rating
    - discount_percentage: Current discount percentage
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    generator = ProductGenerator(seed=format_params.seed)
    products = generator.generate_products(limit=format_params.limit)
    
    return create_response(
        generator,
        products,
        format_params,
        root_name="products",
        item_name="product"
    )

@router.get("/categories", summary="Generate product category data")
async def get_categories(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock product category data with the following fields:
    - category_id: UUID
    - name: Category name
    - description: Category description
    - parent_id: Foreign key to parent category (null for top-level)
    - level: Category level (1 for main, 2 for sub, etc.)
    - created_at: Category creation timestamp
    - updated_at: Last category update timestamp
    - is_active: Whether the category is active
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate (will be adjusted for categories)
    - seed: Random seed for reproducible data
    """
    generator = ProductGenerator(seed=format_params.seed)
    categories = generator.generate_categories()
    
    return create_response(
        generator,
        categories,
        format_params,
        root_name="categories",
        item_name="category"
    )