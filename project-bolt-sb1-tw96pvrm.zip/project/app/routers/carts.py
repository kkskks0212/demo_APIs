from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.user_generator import UserGenerator
from app.generators.product_generator import ProductGenerator
from app.generators.order_generator import OrderGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/carts", ["Shopping Carts"])

@router.get("/", summary="Generate shopping cart data")
async def get_carts(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock shopping cart data with the following fields:
    - cart_id: UUID
    - user_id: Foreign key to user
    - created_at: Cart creation timestamp
    - updated_at: Last cart update timestamp
    - is_active: Whether the cart is active
    - coupon_code: Applied coupon code
    - items: Array of cart items with product details
      - cart_item_id: UUID
      - cart_id: Foreign key to cart
      - product_id: Foreign key to product
      - quantity: Item quantity
      - added_at: When item was added to cart
      - saved_for_later: Whether item is saved for later
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate users and products first for relational integrity
    generator = OrderGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not generator.user_ids:
        user_generator = UserGenerator(seed=format_params.seed)
        users = user_generator.generate_users(limit=format_params.limit // 2)
        generator.user_ids = [u["user_id"] for u in users]
    
    if not generator.product_ids:
        product_generator = ProductGenerator(seed=format_params.seed)
        products = product_generator.generate_products(limit=format_params.limit)
        generator.product_ids = [p["product_id"] for p in products]
    
    carts = generator.generate_carts(limit=format_params.limit)
    
    return create_response(
        generator,
        carts,
        format_params,
        root_name="carts",
        item_name="cart"
    )