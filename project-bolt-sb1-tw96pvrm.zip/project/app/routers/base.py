from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional, Callable
import io
import json
from app.schemas.base import FormatParams
from app.generators.generator import DataGenerator

def get_format_params(
    format: str = Query("json", description="Response format (json, csv, xml)"),
    limit: int = Query(1000, description="Number of records to generate", ge=1, le=10000),
    seed: Optional[int] = Query(None, description="Random seed for reproducible data")
) -> FormatParams:
    return FormatParams(format=format, limit=limit, seed=seed)

def create_response(
    generator: DataGenerator,
    data: List[Dict],
    format_params: FormatParams,
    root_name: str,
    item_name: str
):
    """Create appropriate response based on format"""
    
    # Generate content in requested format
    content = generator.generate_response(
        data, 
        format_params.format,
        root_name=root_name,
        item_name=item_name
    )
    
    # Set appropriate content type and filename
    if format_params.format == "json":
        media_type = "application/json"
        filename = f"{root_name}.json"
    elif format_params.format == "csv":
        media_type = "text/csv"
        filename = f"{root_name}.csv"
    elif format_params.format == "xml":
        media_type = "application/xml"
        filename = f"{root_name}.xml"
    else:
        media_type = "application/json"
        filename = f"{root_name}.json"
    
    # Create streaming response for downloading
    return StreamingResponse(
        io.StringIO(content),
        media_type=media_type,
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )

def create_standard_router(prefix: str, tags: List[str]) -> APIRouter:
    """Create a standard router with common configuration"""
    return APIRouter(prefix=prefix, tags=tags)