from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.schemas.users import UserList, UserResponse
from app.generators.user_generator import UserGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/users", ["Users"])

@router.get("/", summary="Generate user data")
async def get_users(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock user data with the following fields:
    - user_id: UUID
    - email: Email address
    - username: Username
    - first_name: First name
    - last_name: Last name
    - phone_number: Phone number
    - address: Street address
    - city: City
    - state: State
    - postal_code: Postal/ZIP code
    - country: Country
    - created_at: Account creation timestamp
    - updated_at: Last account update timestamp
    - is_active: Whether the user account is active
    - loyalty_points: Loyalty program points
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    generator = UserGenerator(seed=format_params.seed)
    users = generator.generate_users(limit=format_params.limit)
    
    return create_response(
        generator,
        users,
        format_params,
        root_name="users",
        item_name="user"
    )