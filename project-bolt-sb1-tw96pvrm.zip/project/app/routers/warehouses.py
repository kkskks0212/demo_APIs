from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.logistics_generator import LogisticsGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/warehouses", ["Warehouses"])

@router.get("/", summary="Generate warehouse data")
async def get_warehouses(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock warehouse data with the following fields:
    - warehouse_id: UUID
    - name: Warehouse name
    - code: Warehouse code
    - address: Warehouse address
    - city: City
    - state: State
    - postal_code: Postal/ZIP code
    - country: Country
    - latitude: Geographical latitude
    - longitude: Geographical longitude
    - square_footage: Warehouse square footage
    - manager_name: Warehouse manager name
    - phone_number: Warehouse phone number
    - email: Warehouse email
    - created_at: Record creation timestamp
    - updated_at: Last record update timestamp
    - is_active: Whether the warehouse is active
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    logistics_generator = LogisticsGenerator(seed=format_params.seed)
    warehouses = logistics_generator.generate_warehouses(limit=min(format_params.limit, 50))
    
    return create_response(
        logistics_generator,
        warehouses,
        format_params,
        root_name="warehouses",
        item_name="warehouse"
    )