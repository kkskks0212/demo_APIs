from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.product_generator import ProductGenerator
from app.generators.engagement_generator import EngagementGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/promotions", ["Promotions"])

@router.get("/", summary="Generate promotion data")
async def get_promotions(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock promotion data with the following fields:
    - promotion_id: UUID
    - name: Promotion name
    - description: Promotion description
    - code: Promotion code
    - type: Promotion type (percentage_discount, fixed_amount, buy_one_get_one, free_shipping)
    - value: Discount value
    - minimum_purchase: Minimum purchase amount
    - usage_limit: Maximum number of uses
    - usage_count: Current usage count
    - start_date: Promotion start date
    - end_date: Promotion end date
    - created_at: Record creation timestamp
    - updated_at: Last record update timestamp
    - is_active: Whether promotion is active
    - target_type: Target type (all, products, categories)
    - target_ids: Array of target IDs (product or category IDs)
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate products and categories first
    engagement_generator = EngagementGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not engagement_generator.product_ids or not engagement_generator.category_ids:
        product_generator = ProductGenerator(seed=format_params.seed)
        
        # Generate categories first
        categories = product_generator.generate_categories()
        engagement_generator.category_ids = product_generator.category_ids
        
        # Then products
        products = product_generator.generate_products(limit=format_params.limit)
        engagement_generator.product_ids = [p["product_id"] for p in products]
    
    promotions = engagement_generator.generate_promotions(limit=min(format_params.limit, 200))
    
    return create_response(
        engagement_generator,
        promotions,
        format_params,
        root_name="promotions",
        item_name="promotion"
    )