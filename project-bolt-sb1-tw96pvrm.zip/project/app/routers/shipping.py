from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.user_generator import UserGenerator
from app.generators.product_generator import ProductGenerator
from app.generators.order_generator import OrderGenerator
from app.generators.logistics_generator import LogisticsGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/shipping", ["Shipping"])

@router.get("/", summary="Generate shipping data")
async def get_shipping(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock shipping data with the following fields:
    - shipping_id: UUID
    - order_id: Foreign key to order
    - carrier: Shipping carrier (FedEx, UPS, etc.)
    - tracking_number: Shipping tracking number
    - shipping_method: Shipping method
    - status: Shipping status (pending, processing, shipped, delivered, etc.)
    - warehouse_id: Foreign key to warehouse
    - shipped_date: Date shipped
    - delivered_date: Date delivered
    - estimated_delivery: Estimated delivery date
    - shipping_cost: Shipping cost
    - created_at: Record creation timestamp
    - updated_at: Last record update timestamp
    - signature_required: Whether signature is required
    - notes: Shipping notes
    - packages: Number of packages
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate orders and warehouses first
    logistics_generator = LogisticsGenerator(seed=format_params.seed)
    
    # Generate prerequisite data
    user_generator = UserGenerator(seed=format_params.seed)
    users = user_generator.generate_users(limit=format_params.limit // 2)
    
    product_generator = ProductGenerator(seed=format_params.seed)
    products = product_generator.generate_products(limit=format_params.limit)
    
    order_generator = OrderGenerator(seed=format_params.seed)
    order_generator.user_ids = [u["user_id"] for u in users]
    order_generator.product_ids = [p["product_id"] for p in products]
    
    orders = order_generator.generate_orders(limit=format_params.limit)
    
    # Generate warehouses
    warehouses = logistics_generator.generate_warehouses()
    logistics_generator.user_ids = order_generator.user_ids
    logistics_generator.order_ids = [o["order_id"] for o in orders]
    
    shipping = logistics_generator.generate_shipping(orders)
    
    return create_response(
        logistics_generator,
        shipping,
        format_params,
        root_name="shipping",
        item_name="shipping_record"
    )