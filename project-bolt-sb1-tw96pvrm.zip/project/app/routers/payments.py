from fastapi import APIRouter, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Dict, Any, Optional
from app.schemas.base import FormatParams
from app.generators.user_generator import UserGenerator
from app.generators.product_generator import ProductGenerator
from app.generators.order_generator import OrderGenerator
from app.generators.payment_generator import PaymentGenerator
from app.routers.base import get_format_params, create_response, create_standard_router

router = create_standard_router("/payments", ["Payments"])

@router.get("/", summary="Generate payment data")
async def get_payments(format_params: FormatParams = Depends(get_format_params)):
    """
    Generate mock payment data with the following fields:
    - payment_id: UUID
    - order_id: Foreign key to order
    - user_id: Foreign key to user
    - amount: Payment amount
    - currency: Currency code
    - payment_method: Payment method (credit_card, paypal, etc.)
    - status: Payment status (pending, completed, failed, refunded)
    - created_at: Payment creation timestamp
    - updated_at: Last payment update timestamp
    - transaction_id: Payment processor transaction ID
    - payment_provider: Payment processor (stripe, paypal, etc.)
    - card_last_four: Last four digits of card
    - billing_address: Billing address
    - billing_city: Billing city
    - billing_state: Billing state
    - billing_postal_code: Billing postal/ZIP code
    - billing_country: Billing country
    - refund_id: Foreign key to refund
    - is_subscription: Whether this is a subscription payment
    - subscription_id: Foreign key to subscription
    
    You can specify:
    - format: Response format (json, csv, xml)
    - limit: Number of records to generate
    - seed: Random seed for reproducible data
    """
    # Need to generate orders first (which needs users and products)
    order_generator = OrderGenerator(seed=format_params.seed)
    
    # Generate prerequisite data if not already generated
    if not order_generator.user_ids:
        user_generator = UserGenerator(seed=format_params.seed)
        users = user_generator.generate_users(limit=format_params.limit // 2)
        order_generator.user_ids = [u["user_id"] for u in users]
    
    if not order_generator.product_ids:
        product_generator = ProductGenerator(seed=format_params.seed)
        products = product_generator.generate_products(limit=format_params.limit)
        order_generator.product_ids = [p["product_id"] for p in products]
    
    orders = order_generator.generate_orders(limit=format_params.limit)
    
    payment_generator = PaymentGenerator(seed=format_params.seed)
    payment_generator.user_ids = order_generator.user_ids
    payment_generator.order_ids = [o["order_id"] for o in orders]
    
    payments = payment_generator.generate_payments(orders)
    
    return create_response(
        payment_generator,
        payments,
        format_params,
        root_name="payments",
        item_name="payment"
    )