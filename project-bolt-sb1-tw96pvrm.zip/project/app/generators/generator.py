import random
import csv
import json
import io
import xml.dom.minidom as md
import xml.etree.ElementTree as ET
from typing import List, Dict, Any, Callable, Optional
from datetime import datetime, timedelta
from uuid import UUID, uuid4
from faker import Faker
from app.core.config import settings

class DataGenerator:
    def __init__(self, seed: Optional[int] = None):
        self.seed = seed if seed is not None else random.randint(1, 10000)
        self.fake = Faker()
        Faker.seed(self.seed)
        random.seed(self.seed)
        
        # Store generated UUIDs for referential integrity
        self.user_ids = []
        self.product_ids = []
        self.vendor_ids = []
        self.category_ids = []
        self.warehouse_ids = []
        self.order_ids = []
        self.payment_ids = []
        self.shipping_ids = []
        self.ticket_ids = []
        
    def _store_ids(self, entity_type: str, ids: List[UUID]):
        """Store generated UUIDs for later reference"""
        setattr(self, f"{entity_type}_ids", ids)
    
    def _get_random_id(self, entity_type: str) -> UUID:
        """Get a random ID from previously generated entities"""
        ids = getattr(self, f"{entity_type}_ids", [])
        if not ids:
            return uuid4()
        return random.choice(ids)
    
    def _get_random_date(self, start_date=None, end_date=None) -> datetime:
        """Generate a random date within a range"""
        if not start_date:
            start_date = datetime.strptime(settings.DATE_START, '%Y-%m-%d')
        if not end_date:
            end_date = datetime.strptime(settings.DATE_END, '%Y-%m-%d')
        
        time_between_dates = end_date - start_date
        days_between_dates = time_between_dates.days
        random_days = random.randrange(days_between_dates)
        return start_date + timedelta(days=random_days)
    
    def to_json(self, data: List[Dict]) -> str:
        """Convert data to JSON string"""
        return json.dumps(data, default=str, indent=2)
    
    def to_csv(self, data: List[Dict]) -> str:
        """Convert data to CSV string"""
        if not data:
            return ""
        
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=data[0].keys())
        writer.writeheader()
        
        for row in data:
            # Convert any nested objects or complex types to strings
            processed_row = {}
            for k, v in row.items():
                if isinstance(v, (dict, list)):
                    processed_row[k] = json.dumps(v, default=str)
                elif isinstance(v, (datetime, UUID)):
                    processed_row[k] = str(v)
                else:
                    processed_row[k] = v
            writer.writerow(processed_row)
        
        return output.getvalue()
    
    def to_xml(self, data: List[Dict], root_name: str, item_name: str) -> str:
        """Convert data to XML string"""
        root = ET.Element(root_name)
        
        for item in data:
            xml_item = ET.SubElement(root, item_name)
            self._dict_to_xml(item, xml_item)
        
        # Convert to string with pretty formatting
        rough_string = ET.tostring(root, 'utf-8')
        reparsed = md.parseString(rough_string)
        return reparsed.toprettyxml(indent="  ")
    
    def _dict_to_xml(self, d: Dict, parent_element: ET.Element):
        """Helper to convert dict to XML elements"""
        for key, value in d.items():
            if isinstance(value, dict):
                child = ET.SubElement(parent_element, key)
                self._dict_to_xml(value, child)
            elif isinstance(value, list):
                list_element = ET.SubElement(parent_element, key)
                for item in value:
                    if isinstance(item, dict):
                        item_element = ET.SubElement(list_element, "item")
                        self._dict_to_xml(item, item_element)
                    else:
                        item_element = ET.SubElement(list_element, "item")
                        item_element.text = str(item)
            else:
                child = ET.SubElement(parent_element, key)
                child.text = str(value)
    
    def generate_response(self, data: List[Dict], format_type: str, 
                         root_name: str, item_name: str) -> Any:
        """Generate response in the requested format"""
        if format_type == "json":
            return self.to_json(data)
        elif format_type == "csv":
            return self.to_csv(data)
        elif format_type == "xml":
            return self.to_xml(data, root_name, item_name)
        else:
            return self.to_json(data)