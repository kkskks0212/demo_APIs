from app.generators.generator import DataGenerator
from typing import List, Dict, Any, Optional
from uuid import UUID, uuid4
from datetime import datetime, timedelta
import random

class UserGenerator(DataGenerator):
    def generate_users(self, limit: int = 1000) -> List[Dict]:
        """Generate a list of user data"""
        users = []
        for _ in range(limit):
            created_at = self._get_random_date()
            updated_at = created_at + timedelta(days=random.randint(0, 30))
            
            user = {
                "user_id": uuid4(),
                "email": self.fake.email(),
                "username": self.fake.user_name(),
                "first_name": self.fake.first_name(),
                "last_name": self.fake.last_name(),
                "phone_number": self.fake.phone_number(),
                "address": self.fake.street_address(),
                "city": self.fake.city(),
                "state": self.fake.state_abbr(),
                "postal_code": self.fake.zipcode(),
                "country": self.fake.country_code(),
                "created_at": created_at,
                "updated_at": updated_at,
                "is_active": random.random() > 0.1,  # 90% active
                "loyalty_points": random.randint(0, 5000),
                "preferred_payment_method": None  # Will be updated later after payments are generated
            }
            users.append(user)
        
        # Store user IDs for reference in other entities
        self._store_ids("user", [user["user_id"] for user in users])
        return users