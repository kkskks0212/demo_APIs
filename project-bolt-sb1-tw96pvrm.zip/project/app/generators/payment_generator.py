from app.generators.generator import DataGenerator
from typing import List, Dict, Any, Optional
from uuid import UUID, uuid4
from datetime import datetime, timedelta
import random
from decimal import Decimal

class PaymentGenerator(DataGenerator):
    def generate_payments(self, orders: List[Dict]) -> List[Dict]:
        """Generate payment data for orders"""
        payments = []
        payment_methods = ["credit_card", "paypal", "apple_pay", "google_pay", "bank_transfer"]
        payment_statuses = ["completed", "failed", "pending", "refunded"]
        status_weights = [0.85, 0.05, 0.05, 0.05]  # Most are completed
        
        payment_providers = {
            "credit_card": ["stripe", "braintree", "adyen"],
            "paypal": ["paypal"],
            "apple_pay": ["stripe", "braintree"],
            "google_pay": ["stripe", "braintree"],
            "bank_transfer": ["plaid", "stripe"]
        }
        
        for order in orders:
            # Skip some orders to simulate abandoned carts or pending payments
            if random.random() > 0.95:  # 5% of orders have no payment
                continue
                
            payment_method = random.choice(payment_methods)
            provider = random.choice(payment_providers[payment_method])
            status = random.choices(payment_statuses, status_weights)[0]
            
            # Payments happen shortly after order creation
            created_at = order["created_at"] + timedelta(minutes=random.randint(1, 30))
            updated_at = created_at
            
            # For refunded payments, update the timestamp
            refund_id = None
            if status == "refunded":
                refund_delay = random.randint(1, 14)  # Refunded 1-14 days later
                updated_at = created_at + timedelta(days=refund_delay)
                refund_id = uuid4()
            
            payment_id = uuid4()
            
            payment = {
                "payment_id": payment_id,
                "order_id": order["order_id"],
                "user_id": order["user_id"],
                "amount": order["total"],
                "currency": "USD",
                "payment_method": payment_method,
                "status": status,
                "created_at": created_at,
                "updated_at": updated_at,
                "transaction_id": self.fake.uuid4(),
                "payment_provider": provider,
                "card_last_four": self.fake.bothify(text="####") if payment_method == "credit_card" else None,
                "billing_address": order["shipping_address"],
                "billing_city": order["shipping_city"],
                "billing_state": order["shipping_state"],
                "billing_postal_code": order["shipping_postal_code"],
                "billing_country": order["shipping_country"],
                "refund_id": refund_id,
                "is_subscription": False,
                "subscription_id": None
            }
            
            # Update the order with the payment ID
            order["payment_id"] = payment_id
            
            payments.append(payment)
        
        # Store payment IDs for reference
        self._store_ids("payment", [payment["payment_id"] for payment in payments])
        return payments
    
    def generate_subscriptions(self, limit: int = 200) -> List[Dict]:
        """Generate subscription data"""
        if not self.user_ids:
            raise ValueError("User IDs must be generated before subscriptions")
        
        if not self.product_ids:
            raise ValueError("Product IDs must be generated before subscriptions")
            
        subscriptions = []
        subscription_plans = ["monthly", "quarterly", "annual"]
        statuses = ["active", "cancelled", "paused", "past_due"]
        status_weights = [0.7, 0.15, 0.1, 0.05]  # Most are active
        
        for _ in range(limit):
            user_id = self._get_random_id("user")
            start_date = self._get_random_date()
            
            plan = random.choice(subscription_plans)
            status = random.choices(statuses, status_weights)[0]
            
            # Calculate next billing date based on plan
            if plan == "monthly":
                interval = 30
                amount = Decimal(str(round(random.uniform(9.99, 29.99), 2)))
            elif plan == "quarterly":
                interval = 90
                amount = Decimal(str(round(random.uniform(24.99, 69.99), 2)))
            else:  # annual
                interval = 365
                amount = Decimal(str(round(random.uniform(99.99, 199.99), 2)))
            
            # Calculate dates
            next_billing = start_date + timedelta(days=interval)
            end_date = None
            
            if status == "cancelled":
                cancel_days = random.randint(1, interval - 1)
                end_date = start_date + timedelta(days=cancel_days)
            
            # Generate 1-3 products included in the subscription
            num_products = random.randint(1, 3)
            selected_product_ids = random.sample(self.product_ids, min(num_products, len(self.product_ids)))
            
            subscription_id = uuid4()
            
            subscription = {
                "subscription_id": subscription_id,
                "user_id": user_id,
                "plan": plan,
                "status": status,
                "amount": amount,
                "currency": "USD",
                "start_date": start_date,
                "next_billing_date": next_billing if status in ["active", "paused", "past_due"] else None,
                "end_date": end_date,
                "payment_method": random.choice(["credit_card", "paypal"]),
                "auto_renew": random.random() > 0.1,  # 90% auto-renew
                "products": selected_product_ids,
                "created_at": start_date,
                "updated_at": end_date if end_date else start_date,
                "last_payment_date": start_date,
                "total_payments": random.randint(1, 12),
                "discount_percent": round(random.uniform(0, 0.2), 2) if random.random() > 0.7 else 0
            }
            
            subscriptions.append(subscription)
        
        return subscriptions