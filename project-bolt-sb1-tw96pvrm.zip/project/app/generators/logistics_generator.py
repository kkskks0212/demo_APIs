from app.generators.generator import DataGenerator
from typing import List, Dict, Any, Optional
from uuid import UUID, uuid4
from datetime import datetime, timedelta
import random
from decimal import Decimal

class LogisticsGenerator(DataGenerator):
    def generate_warehouses(self, limit: int = 20) -> List[Dict]:
        """Generate warehouse data"""
        warehouses = []
        
        for _ in range(limit):
            created_at = self._get_random_date()
            warehouse_id = uuid4()
            
            warehouse = {
                "warehouse_id": warehouse_id,
                "name": f"{self.fake.city()} Distribution Center",
                "code": self.fake.bothify(text="WH-???##").upper(),
                "address": self.fake.street_address(),
                "city": self.fake.city(),
                "state": self.fake.state_abbr(),
                "postal_code": self.fake.zipcode(),
                "country": "US",
                "latitude": float(self.fake.latitude()),
                "longitude": float(self.fake.longitude()),
                "square_footage": random.randint(20000, 500000),
                "manager_name": self.fake.name(),
                "phone_number": self.fake.phone_number(),
                "email": self.fake.company_email(),
                "created_at": created_at,
                "updated_at": created_at + timedelta(days=random.randint(0, 180)),
                "is_active": random.random() > 0.1  # 90% active
            }
            warehouses.append(warehouse)
        
        # Store warehouse IDs for reference
        self._store_ids("warehouse", [w["warehouse_id"] for w in warehouses])
        return warehouses
    
    def generate_inventory(self, limit: int = 5000) -> List[Dict]:
        """Generate inventory data"""
        if not self.warehouse_ids:
            raise ValueError("Warehouse IDs must be generated before inventory")
            
        if not self.product_ids:
            raise ValueError("Product IDs must be generated before inventory")
        
        inventory = []
        
        # Create inventory records by combining products and warehouses
        for product_id in self.product_ids[:limit]:
            # Each product can be in multiple warehouses
            for _ in range(random.randint(1, 3)):
                warehouse_id = self._get_random_id("warehouse")
                created_at = self._get_random_date()
                updated_at = created_at + timedelta(days=random.randint(0, 30))
                
                inventory_id = uuid4()
                
                record = {
                    "inventory_id": inventory_id,
                    "product_id": product_id,
                    "warehouse_id": warehouse_id,
                    "quantity": random.randint(0, 500),
                    "min_stock_level": random.randint(5, 50),
                    "max_stock_level": random.randint(100, 1000),
                    "shelf_location": f"{random.choice('ABCDEFGH')}-{random.randint(1,99)}-{random.randint(1,99)}",
                    "created_at": created_at,
                    "updated_at": updated_at,
                    "last_restock_date": created_at - timedelta(days=random.randint(1, 60)),
                    "next_restock_date": updated_at + timedelta(days=random.randint(1, 30)) if random.random() > 0.3 else None,
                    "is_in_stock": random.random() > 0.1  # 90% in stock
                }
                
                inventory.append(record)
        
        return inventory
    
    def generate_shipping(self, orders: List[Dict]) -> List[Dict]:
        """Generate shipping data for orders"""
        if not self.warehouse_ids:
            raise ValueError("Warehouse IDs must be generated before shipping")
        
        shipping_records = []
        carriers = ["FedEx", "UPS", "USPS", "DHL", "Amazon Logistics"]
        shipping_statuses = {
            "pending": ["pending", "processing"],
            "shipped": ["shipped"],
            "delivered": ["delivered"],
            "cancelled": ["cancelled"]
        }
        
        for order in orders:
            # Skip orders with cancelled status
            if order["status"] == "cancelled":
                continue
                
            order_status = order["status"]
            possible_statuses = shipping_statuses.get(order_status, ["pending"])
            shipping_status = random.choice(possible_statuses)
            
            # Create shipping dates based on order dates
            shipped_date = None
            delivered_date = None
            estimated_delivery = order.get("estimated_delivery")
            
            if shipping_status in ["shipped", "delivered"]:
                # Shipped 1-2 days after order creation
                shipped_date = order["created_at"] + timedelta(days=random.randint(1, 2))
                
                if shipping_status == "delivered":
                    # Delivered on or near the estimated date
                    if estimated_delivery:
                        delivered_date = estimated_delivery
                    else:
                        # If no estimate, deliver 2-7 days after shipping
                        delivered_date = shipped_date + timedelta(days=random.randint(2, 7))
            
            carrier = random.choice(carriers)
            shipping_id = uuid4()
            
            shipping = {
                "shipping_id": shipping_id,
                "order_id": order["order_id"],
                "carrier": carrier,
                "tracking_number": order["tracking_number"] if order["tracking_number"] else self.fake.bothify(text="?#?#?#-########"),
                "shipping_method": order["shipping_method"],
                "status": shipping_status,
                "warehouse_id": self._get_random_id("warehouse"),
                "shipped_date": shipped_date,
                "delivered_date": delivered_date,
                "estimated_delivery": estimated_delivery,
                "shipping_cost": order["shipping_cost"],
                "created_at": order["created_at"],
                "updated_at": delivered_date if delivered_date else (shipped_date if shipped_date else order["created_at"]),
                "signature_required": random.random() > 0.7,  # 30% require signature
                "notes": self.fake.text(max_nb_chars=100) if random.random() > 0.9 else None,
                "packages": random.randint(1, 3)
            }
            
            shipping_records.append(shipping)
        
        # Store shipping IDs for reference
        self._store_ids("shipping", [s["shipping_id"] for s in shipping_records])
        return shipping_records
    
    def generate_returns(self, orders: List[Dict], limit: int = 200) -> List[Dict]:
        """Generate return data for orders"""
        if not self.warehouse_ids:
            raise ValueError("Warehouse IDs must be generated before returns")
        
        returns = []
        
        # Filter orders that are delivered and can be returned
        delivered_orders = [o for o in orders if o["status"] == "delivered"]
        
        # If not enough delivered orders, adjust limit
        limit = min(limit, len(delivered_orders))
        
        # Randomly select orders for return
        return_orders = random.sample(delivered_orders, limit)
        
        return_statuses = ["pending", "approved", "received", "processed", "refunded", "denied"]
        return_reasons = [
            "Damaged during shipping", 
            "Wrong size", 
            "Wrong color", 
            "Not as described", 
            "Changed mind", 
            "Defective product", 
            "Arrived too late", 
            "Received wrong item"
        ]
        
        for order in return_orders:
            # Returns happen after delivery, within 30 days
            delivery_date = order.get("actual_delivery")
            if not delivery_date:
                continue
                
            return_request_date = delivery_date + timedelta(days=random.randint(1, 30))
            
            # Select random items from the order to return (not always all items)
            items_to_return = []
            for item in order["items"]:
                if random.random() > 0.3:  # 70% chance to return each item
                    items_to_return.append({
                        "order_item_id": item["order_item_id"],
                        "product_id": item["product_id"],
                        "quantity": random.randint(1, item["quantity"]),  # May return partial quantity
                        "reason": random.choice(return_reasons),
                        "condition": random.choice(["unopened", "used", "damaged"])
                    })
            
            # If no items to return, skip this order
            if not items_to_return:
                continue
                
            status = random.choice(return_statuses)
            
            # Calculate dates based on status
            approved_date = None
            received_date = None
            processed_date = None
            refunded_date = None
            
            if status in ["approved", "received", "processed", "refunded"]:
                approved_date = return_request_date + timedelta(days=random.randint(1, 3))
                
                if status in ["received", "processed", "refunded"]:
                    received_date = approved_date + timedelta(days=random.randint(3, 10))
                    
                    if status in ["processed", "refunded"]:
                        processed_date = received_date + timedelta(days=random.randint(1, 5))
                        
                        if status == "refunded":
                            refunded_date = processed_date + timedelta(days=random.randint(1, 3))
            
            # Calculate total refund amount
            refund_amount = sum(item["unit_price"] * item_return["quantity"] 
                               for item, item_return in zip(order["items"], items_to_return)
                               if item["order_item_id"] == item_return["order_item_id"])
            
            return_id = uuid4()
            
            return_data = {
                "return_id": return_id,
                "order_id": order["order_id"],
                "user_id": order["user_id"],
                "status": status,
                "request_date": return_request_date,
                "approved_date": approved_date,
                "received_date": received_date,
                "processed_date": processed_date,
                "refunded_date": refunded_date,
                "refund_amount": refund_amount,
                "return_method": random.choice(["mail", "in_store"]),
                "tracking_number": self.fake.bothify(text="RET-########") if status in ["approved", "received", "processed", "refunded"] else None,
                "warehouse_id": self._get_random_id("warehouse") if status in ["received", "processed", "refunded"] else None,
                "notes": self.fake.text(max_nb_chars=100) if random.random() > 0.7 else None,
                "created_at": return_request_date,
                "updated_at": refunded_date or processed_date or received_date or approved_date or return_request_date,
                "items": items_to_return
            }
            
            returns.append(return_data)
        
        return returns