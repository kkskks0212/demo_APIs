from app.generators.generator import DataGenerator
from typing import List, Dict, Any, Optional
from uuid import UUID, uuid4
from datetime import datetime, timedelta
import random
from decimal import Decimal

class AnalyticsGenerator(DataGenerator):
    def generate_user_analytics(self, limit: int = 1000) -> List[Dict]:
        """Generate user analytics data"""
        if not self.user_ids:
            raise ValueError("User IDs must be generated before user analytics")
        
        analytics = []
        
        for _ in range(limit):
            user_id = self._get_random_id("user")
            date = self._get_random_date()
            
            # Generate session data
            num_sessions = random.randint(1, 10)
            total_session_time = random.randint(60, 3600 * 3)  # 1 minute to 3 hours in seconds
            avg_session_time = total_session_time // num_sessions
            
            # Generate page view data
            pages_viewed = random.randint(5, 50)
            
            # Device and platform info
            device_type = random.choice(["mobile", "desktop", "tablet"])
            platform = random.choice(["web", "ios", "android"])
            
            # Referral source
            referral_source = random.choice([
                "direct", "google", "facebook", "instagram", "email", "affiliate", 
                "bing", "twitter", "pinterest", "youtube"
            ])
            
            # Shopping behavior
            cart_adds = random.randint(0, 10)
            cart_abandons = random.randint(0, cart_adds)
            purchases = random.randint(0, cart_adds - cart_abandons)
            
            # Calculate conversion metrics
            cart_add_rate = pages_viewed > 0 and cart_adds / pages_viewed or 0
            conversion_rate = cart_adds > 0 and purchases / cart_adds or 0
            
            analytics_id = uuid4()
            
            record = {
                "analytics_id": analytics_id,
                "user_id": user_id,
                "date": date,
                "sessions": num_sessions,
                "total_session_time": total_session_time,
                "avg_session_time": avg_session_time,
                "pages_viewed": pages_viewed,
                "device_type": device_type,
                "platform": platform,
                "referral_source": referral_source,
                "cart_adds": cart_adds,
                "cart_abandons": cart_abandons,
                "purchases": purchases,
                "cart_add_rate": round(cart_add_rate, 4),
                "conversion_rate": round(conversion_rate, 4),
                "created_at": date + timedelta(days=1),  # Analytics recorded the next day
                "location": {
                    "country": self.fake.country(),
                    "city": self.fake.city(),
                    "region": self.fake.state()
                }
            }
            
            analytics.append(record)
        
        return analytics
    
    def generate_product_analytics(self, limit: int = 1000) -> List[Dict]:
        """Generate product analytics data"""
        if not self.product_ids:
            raise ValueError("Product IDs must be generated before product analytics")
        
        analytics = []
        
        for _ in range(limit):
            product_id = self._get_random_id("product")
            date = self._get_random_date()
            
            # Generate view data
            views = random.randint(10, 1000)
            unique_views = random.randint(5, views)
            
            # Generate interaction metrics
            add_to_cart_count = random.randint(0, unique_views // 2)
            add_to_wishlist_count = random.randint(0, unique_views // 4)
            purchase_count = random.randint(0, add_to_cart_count)
            units_sold = random.randint(purchase_count, purchase_count * 3)
            
            # Calculate conversion metrics
            cart_add_rate = unique_views > 0 and add_to_cart_count / unique_views or 0
            purchase_rate = add_to_cart_count > 0 and purchase_count / add_to_cart_count or 0
            
            # Revenue data
            avg_price = Decimal(str(round(random.uniform(9.99, 199.99), 2)))
            revenue = avg_price * units_sold
            
            analytics_id = uuid4()
            
            record = {
                "analytics_id": analytics_id,
                "product_id": product_id,
                "date": date,
                "views": views,
                "unique_views": unique_views,
                "add_to_cart_count": add_to_cart_count,
                "add_to_wishlist_count": add_to_wishlist_count,
                "purchase_count": purchase_count,
                "units_sold": units_sold,
                "cart_add_rate": round(cart_add_rate, 4),
                "purchase_rate": round(purchase_rate, 4),
                "avg_price": avg_price,
                "revenue": revenue,
                "created_at": date + timedelta(days=1),  # Analytics recorded the next day
                "referral_sources": {
                    "direct": random.randint(0, unique_views // 3),
                    "search": random.randint(0, unique_views // 3),
                    "social": random.randint(0, unique_views // 3),
                    "email": random.randint(0, unique_views // 5),
                    "affiliate": random.randint(0, unique_views // 10)
                }
            }
            
            analytics.append(record)
        
        return analytics