from app.generators.generator import DataGenerator
from typing import List, Dict, Any, Optional
from uuid import UUID, uuid4
from datetime import datetime, timedelta
import random
from decimal import Decimal

class OrderGenerator(DataGenerator):
    def generate_orders(self, limit: int = 1000) -> List[Dict]:
        """Generate order data with items"""
        if not self.user_ids:
            raise ValueError("User IDs must be generated before orders")
        
        if not self.product_ids:
            raise ValueError("Product IDs must be generated before orders")
        
        orders = []
        status_options = ["pending", "processing", "shipped", "delivered", "cancelled"]
        status_weights = [0.05, 0.15, 0.20, 0.55, 0.05]  # Probabilities for each status
        
        shipping_methods = [
            "Standard Shipping", 
            "Express Shipping", 
            "Next Day Delivery", 
            "Free Shipping", 
            "Economy Shipping"
        ]
        
        for _ in range(limit):
            user_id = self._get_random_id("user")
            created_at = self._get_random_date()
            
            # Determine status and related dates
            status = random.choices(status_options, status_weights)[0]
            updated_at = created_at + timedelta(days=random.randint(0, 7))
            
            # Calculate reasonable delivery estimates based on status
            estimated_delivery = None
            actual_delivery = None
            
            if status != "cancelled":
                days_to_deliver = random.randint(2, 14)
                estimated_delivery = created_at + timedelta(days=days_to_deliver)
                
                if status == "delivered":
                    # Actual delivery is around estimated time (slightly early to slightly late)
                    variance = random.randint(-2, 3)  # -2 days early to 3 days late
                    actual_delivery = estimated_delivery + timedelta(days=variance)
            
            # Generate order items first to calculate totals
            num_items = random.randint(1, 5)
            items = []
            subtotal = Decimal('0.00')
            
            # Avoid duplicate products in the same order
            selected_product_ids = random.sample(self.product_ids, min(num_items, len(self.product_ids)))
            
            for product_id in selected_product_ids:
                quantity = random.randint(1, 5)
                unit_price = Decimal(str(round(random.uniform(9.99, 299.99), 2)))
                item_discount = Decimal('0.00')
                
                # Sometimes apply item-level discount
                if random.random() > 0.7:
                    discount_percent = Decimal(str(round(random.uniform(0.05, 0.25), 2)))
                    item_discount = round(unit_price * quantity * discount_percent, 2)
                
                item_total = round((unit_price * quantity) - item_discount, 2)
                subtotal += item_total
                
                item = {
                    "order_item_id": uuid4(),
                    "order_id": None,  # Will be set after order is created
                    "product_id": product_id,
                    "quantity": quantity,
                    "unit_price": unit_price,
                    "discount": item_discount,
                    "total": item_total,
                    "is_gift": random.random() > 0.9,  # 10% are gifts
                    "gift_message": self.fake.text(max_nb_chars=100) if random.random() > 0.9 else None
                }
                items.append(item)
            
            # Calculate order totals
            shipping_cost = Decimal(str(round(random.uniform(0.00, 25.00), 2)))
            if shipping_methods[3] in shipping_methods:  # Free shipping
                shipping_cost = Decimal('0.00')
                
            # Apply order-level discount
            discount = Decimal('0.00')
            coupon_code = None
            if random.random() > 0.7:  # 30% have a coupon
                discount_percent = Decimal(str(round(random.uniform(0.05, 0.15), 2)))
                discount = round(subtotal * discount_percent, 2)
                coupon_code = self.fake.bothify(text="???##").upper()
            
            tax_rate = Decimal(str(round(random.uniform(0.05, 0.12), 2)))
            tax = round(subtotal * tax_rate, 2)
            total = subtotal + shipping_cost + tax - discount
            
            # Create the order
            order_id = uuid4()
            
            order = {
                "order_id": order_id,
                "user_id": user_id,
                "status": status,
                "created_at": created_at,
                "updated_at": updated_at,
                "shipping_address": self.fake.street_address(),
                "shipping_city": self.fake.city(),
                "shipping_state": self.fake.state_abbr(),
                "shipping_postal_code": self.fake.zipcode(),
                "shipping_country": "US",
                "shipping_method": random.choice(shipping_methods),
                "shipping_cost": shipping_cost,
                "subtotal": subtotal,
                "tax": tax,
                "discount": discount,
                "total": total,
                "coupon_code": coupon_code,
                "notes": self.fake.text(max_nb_chars=150) if random.random() > 0.9 else None,
                "tracking_number": self.fake.bothify(text="?#?#?#-########") if status in ["shipped", "delivered"] else None,
                "estimated_delivery": estimated_delivery,
                "actual_delivery": actual_delivery,
                "payment_id": None,  # Will be linked after payment generation
                "items": []
            }
            
            # Update items with order_id and add to order
            for item in items:
                item["order_id"] = order_id
            
            order["items"] = items
            orders.append(order)
        
        # Store order IDs for reference in payments, shipping, etc.
        self._store_ids("order", [order["order_id"] for order in orders])
        return orders
    
    def generate_carts(self, limit: int = 500) -> List[Dict]:
        """Generate shopping cart data"""
        if not self.user_ids:
            raise ValueError("User IDs must be generated before carts")
        
        if not self.product_ids:
            raise ValueError("Product IDs must be generated before carts")
        
        carts = []
        
        for _ in range(limit):
            user_id = self._get_random_id("user")
            created_at = self._get_random_date()
            updated_at = created_at + timedelta(minutes=random.randint(5, 120))
            
            # Generate cart items
            num_items = random.randint(1, 10)
            items = []
            
            # Avoid duplicate products in the same cart
            selected_product_ids = random.sample(self.product_ids, min(num_items, len(self.product_ids)))
            
            for product_id in selected_product_ids:
                quantity = random.randint(1, 3)
                added_at = updated_at - timedelta(minutes=random.randint(1, 60))
                
                item = {
                    "cart_item_id": uuid4(),
                    "cart_id": None,  # Will be set after cart is created
                    "product_id": product_id,
                    "quantity": quantity,
                    "added_at": added_at,
                    "saved_for_later": random.random() > 0.85  # 15% saved for later
                }
                items.append(item)
            
            # Create the cart
            cart_id = uuid4()
            
            cart = {
                "cart_id": cart_id,
                "user_id": user_id,
                "created_at": created_at,
                "updated_at": updated_at,
                "is_active": random.random() > 0.3,  # 70% active
                "coupon_code": self.fake.bothify(text="???##").upper() if random.random() > 0.8 else None,
                "items": []
            }
            
            # Update items with cart_id
            for item in items:
                item["cart_id"] = cart_id
            
            cart["items"] = items
            carts.append(cart)
        
        return carts
    
    def generate_wishlists(self, limit: int = 300) -> List[Dict]:
        """Generate wishlist data"""
        if not self.user_ids:
            raise ValueError("User IDs must be generated before wishlists")
        
        if not self.product_ids:
            raise ValueError("Product IDs must be generated before wishlists")
        
        wishlists = []
        
        for _ in range(limit):
            user_id = self._get_random_id("user")
            created_at = self._get_random_date()
            
            # Generate wishlist items
            num_items = random.randint(1, 15)
            items = []
            
            # Avoid duplicate products in the same wishlist
            selected_product_ids = random.sample(self.product_ids, min(num_items, len(self.product_ids)))
            
            for product_id in selected_product_ids:
                added_at = created_at + timedelta(days=random.randint(0, 60))
                
                item = {
                    "wishlist_item_id": uuid4(),
                    "wishlist_id": None,  # Will be set after wishlist is created
                    "product_id": product_id,
                    "added_at": added_at,
                    "priority": random.randint(1, 5),  # 1-5 priority rating
                    "notes": self.fake.sentence() if random.random() > 0.7 else None
                }
                items.append(item)
            
            # Create the wishlist
            wishlist_id = uuid4()
            
            wishlist = {
                "wishlist_id": wishlist_id,
                "user_id": user_id,
                "name": random.choice(["My Wishlist", "Birthday Wishlist", "Holiday Wishlist", "Gift Ideas", self.fake.word().capitalize() + " Wishlist"]),
                "description": self.fake.sentence() if random.random() > 0.5 else None,
                "created_at": created_at,
                "updated_at": created_at + timedelta(days=random.randint(0, 90)),
                "is_public": random.random() > 0.6,  # 40% public
                "items": []
            }
            
            # Update items with wishlist_id
            for item in items:
                item["wishlist_id"] = wishlist_id
            
            wishlist["items"] = items
            wishlists.append(wishlist)
        
        return wishlists