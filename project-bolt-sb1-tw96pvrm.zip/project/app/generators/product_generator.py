from app.generators.generator import DataGenerator
from typing import List, Dict, Any, Optional
from uuid import UUID, uuid4
from datetime import datetime, timedelta
import random
from decimal import Decimal

class ProductGenerator(DataGenerator):
    def generate_categories(self, limit: int = 20) -> List[Dict]:
        """Generate product categories"""
        categories = []
        parent_categories = ["Electronics", "Clothing", "Home & Garden", "Beauty", "Sports", "Books", "Toys", "Automotive"]
        
        for i, parent in enumerate(parent_categories):
            parent_id = uuid4()
            created_at = self._get_random_date()
            updated_at = created_at + timedelta(days=random.randint(0, 30))
            
            category = {
                "category_id": parent_id,
                "name": parent,
                "description": self.fake.paragraph(),
                "parent_id": None,
                "level": 1,
                "created_at": created_at,
                "updated_at": updated_at,
                "is_active": True
            }
            categories.append(category)
            
            # Add subcategories
            for _ in range(random.randint(2, 5)):
                sub_id = uuid4()
                sub_created_at = self._get_random_date()
                sub_updated_at = sub_created_at + timedelta(days=random.randint(0, 30))
                
                subcategory = {
                    "category_id": sub_id,
                    "name": self.fake.word().capitalize() + " " + parent,
                    "description": self.fake.paragraph(),
                    "parent_id": parent_id,
                    "level": 2,
                    "created_at": sub_created_at,
                    "updated_at": sub_updated_at,
                    "is_active": random.random() > 0.1  # 90% active
                }
                categories.append(subcategory)
        
        # Store category IDs for reference in products
        self._store_ids("category", [cat["category_id"] for cat in categories])
        return categories
    
    def generate_vendors(self, limit: int = 50) -> List[Dict]:
        """Generate product vendors/suppliers"""
        vendors = []
        for _ in range(limit):
            created_at = self._get_random_date()
            updated_at = created_at + timedelta(days=random.randint(0, 90))
            
            vendor = {
                "vendor_id": uuid4(),
                "name": self.fake.company(),
                "description": self.fake.catch_phrase(),
                "contact_name": self.fake.name(),
                "contact_email": self.fake.company_email(),
                "contact_phone": self.fake.phone_number(),
                "address": self.fake.street_address(),
                "city": self.fake.city(),
                "state": self.fake.state_abbr(),
                "postal_code": self.fake.zipcode(),
                "country": self.fake.country_code(),
                "website": self.fake.url(),
                "created_at": created_at,
                "updated_at": updated_at,
                "rating": round(random.uniform(3.0, 5.0), 1),
                "is_active": random.random() > 0.15  # 85% active
            }
            vendors.append(vendor)
        
        # Store vendor IDs for reference in products
        self._store_ids("vendor", [vendor["vendor_id"] for vendor in vendors])
        return vendors
    
    def generate_products(self, limit: int = 1000) -> List[Dict]:
        """Generate product data"""
        if not self.category_ids:
            self.generate_categories()
        
        if not self.vendor_ids:
            self.generate_vendors()
        
        products = []
        product_adjectives = ["Premium", "Ultra", "Deluxe", "Essential", "Professional", "Advanced", "Basic", "Custom", "Smart", "Eco-friendly"]
        product_types = ["Laptop", "Phone", "Camera", "Headphones", "Watch", "Shoes", "Shirt", "Pants", "Book", "Tablet", "Chair", "Table", "Lamp", "Toy", "Game"]
        
        for _ in range(limit):
            created_at = self._get_random_date()
            updated_at = created_at + timedelta(days=random.randint(0, 60))
            
            price = round(Decimal(random.uniform(9.99, 999.99)), 2)
            cost = round(price * Decimal(random.uniform(0.4, 0.8)), 2)  # Cost is 40-80% of price
            
            name = f"{random.choice(product_adjectives)} {random.choice(product_types)}"
            if random.random() > 0.7:  # 30% have a brand name
                name = f"{self.fake.company().split()[0]} {name}"
            
            product = {
                "product_id": uuid4(),
                "name": name,
                "description": self.fake.paragraph(),
                "sku": self.fake.bothify(text="???-######"),
                "price": price,
                "cost": cost,
                "weight": round(random.uniform(0.1, 20.0), 2),
                "dimensions": f"{random.randint(1, 100)}x{random.randint(1, 100)}x{random.randint(1, 100)}",
                "category_id": self._get_random_id("category"),
                "vendor_id": self._get_random_id("vendor"),
                "created_at": created_at,
                "updated_at": updated_at,
                "is_active": random.random() > 0.2,  # 80% active
                "stock_quantity": random.randint(0, 1000),
                "tags": [self.fake.word() for _ in range(random.randint(1, 5))],
                "image_url": f"https://picsum.photos/id/{random.randint(1, 1000)}/500/500",
                "average_rating": round(random.uniform(1.0, 5.0), 1),
                "discount_percentage": round(random.uniform(0, 0.5), 2) if random.random() > 0.7 else 0.0
            }
            products.append(product)
        
        # Store product IDs for reference in orders, etc.
        self._store_ids("product", [product["product_id"] for product in products])
        return products