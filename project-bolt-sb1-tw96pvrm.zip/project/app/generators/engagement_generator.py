from app.generators.generator import DataGenerator
from typing import List, Dict, Any, Optional
from uuid import UUID, uuid4
from datetime import datetime, timedelta
import random
from decimal import Decimal

class EngagementGenerator(DataGenerator):
    def generate_reviews(self, limit: int = 2000) -> List[Dict]:
        """Generate product review data"""
        if not self.user_ids:
            raise ValueError("User IDs must be generated before reviews")
            
        if not self.product_ids:
            raise ValueError("Product IDs must be generated before reviews")
            
        if not self.order_ids:
            raise ValueError("Order IDs must be generated before reviews")
        
        reviews = []
        
        for _ in range(limit):
            user_id = self._get_random_id("user")
            product_id = self._get_random_id("product")
            order_id = self._get_random_id("order")
            created_at = self._get_random_date()
            
            # Determine if review was edited
            updated_at = created_at
            if random.random() > 0.8:  # 20% of reviews are edited
                updated_at = created_at + timedelta(days=random.randint(1, 30))
            
            # Generate rating
            rating = random.randint(1, 5)
            
            # Generate review title and content based on rating
            if rating >= 4:  # Positive reviews
                title_templates = [
                    "Great product!", "Love it!", "Excellent quality", "Highly recommended", 
                    "Exceeded expectations", "Worth every penny", "Just what I needed"
                ]
                review_length = random.randint(50, 200)
            elif rating == 3:  # Neutral reviews
                title_templates = [
                    "Decent product", "Good but not great", "Okay for the price", 
                    "Some pros and cons", "Middle of the road", "Mixed feelings"
                ]
                review_length = random.randint(70, 150)
            else:  # Negative reviews
                title_templates = [
                    "Disappointed", "Not worth it", "Don't buy this", "Poor quality", 
                    "Waste of money", "Didn't meet expectations", "Had issues with this"
                ]
                review_length = random.randint(100, 250)  # Negative reviews tend to be longer
            
            review_id = uuid4()
            
            review = {
                "review_id": review_id,
                "product_id": product_id,
                "user_id": user_id,
                "order_id": order_id,
                "rating": rating,
                "title": random.choice(title_templates),
                "content": self.fake.text(max_nb_chars=review_length),
                "created_at": created_at,
                "updated_at": updated_at,
                "helpful_votes": random.randint(0, 50),
                "verified_purchase": random.random() > 0.1,  # 90% verified
                "images": [f"https://picsum.photos/id/{random.randint(1, 1000)}/200/200" for _ in range(random.randint(0, 3))] if random.random() > 0.7 else [],
                "is_featured": random.random() > 0.9  # 10% featured
            }
            
            reviews.append(review)
        
        return reviews
    
    def generate_support_tickets(self, limit: int = 500) -> List[Dict]:
        """Generate customer support ticket data"""
        if not self.user_ids:
            raise ValueError("User IDs must be generated before support tickets")
            
        # Some tickets are related to orders, some are not
        order_related_ratio = 0.7  # 70% of tickets are order-related
        
        tickets = []
        ticket_types = ["question", "issue", "complaint", "refund_request", "return_request", "technical_support"]
        priorities = ["low", "medium", "high", "urgent"]
        statuses = ["new", "in_progress", "waiting_for_customer", "resolved", "closed"]
        
        for _ in range(limit):
            user_id = self._get_random_id("user")
            created_at = self._get_random_date()
            
            # Determine if ticket is order-related
            is_order_related = random.random() < order_related_ratio
            order_id = self._get_random_id("order") if is_order_related and self.order_ids else None
            
            # Determine ticket type based on order relation
            if is_order_related:
                ticket_type = random.choice(["issue", "complaint", "refund_request", "return_request"])
            else:
                ticket_type = random.choice(["question", "technical_support"])
            
            # Generate subject based on ticket type
            if ticket_type == "question":
                subject = random.choice([
                    "Question about product compatibility", 
                    "Shipping timeframes", 
                    "Payment methods", 
                    "How to use feature X"
                ])
            elif ticket_type == "issue":
                subject = random.choice([
                    "Problem with my order", 
                    "Missing items", 
                    "Damaged packaging", 
                    "Wrong item received"
                ])
            elif ticket_type == "complaint":
                subject = random.choice([
                    "Unhappy with product quality", 
                    "Poor customer service", 
                    "Late delivery", 
                    "Misleading product description"
                ])
            elif ticket_type == "refund_request":
                subject = random.choice([
                    "Requesting refund for order", 
                    "Refund for damaged item", 
                    "Refund for unused service"
                ])
            elif ticket_type == "return_request":
                subject = random.choice([
                    "Need to return item", 
                    "Return policy question", 
                    "Return without receipt"
                ])
            else:  # technical_support
                subject = random.choice([
                    "Product not working", 
                    "Setup instructions unclear", 
                    "Software compatibility issue", 
                    "Trouble with installation"
                ])
            
            # Determine status and related dates
            status = random.choice(statuses)
            
            updated_at = created_at
            resolved_at = None
            closed_at = None
            assigned_to = None
            
            if status != "new":
                # Ticket was updated after creation
                updated_at = created_at + timedelta(hours=random.randint(1, 48))
                assigned_to = self.fake.name()
                
                if status in ["resolved", "closed"]:
                    resolved_at = updated_at + timedelta(hours=random.randint(1, 72))
                    
                    if status == "closed":
                        closed_at = resolved_at + timedelta(hours=random.randint(1, 24))
            
            # Generate response time and resolution time metrics
            first_response_time = None
            if status != "new":
                # First response within 1-24 hours
                first_response_time = random.randint(1, 24)
            
            resolution_time = None
            if resolved_at:
                # Resolution time in hours
                resolution_time = int((resolved_at - created_at).total_seconds() / 3600)
            
            ticket_id = uuid4()
            
            ticket = {
                "ticket_id": ticket_id,
                "user_id": user_id,
                "order_id": order_id,
                "subject": subject,
                "description": self.fake.text(max_nb_chars=300),
                "type": ticket_type,
                "priority": random.choices(priorities, weights=[0.3, 0.4, 0.2, 0.1])[0],
                "status": status,
                "created_at": created_at,
                "updated_at": updated_at,
                "resolved_at": resolved_at,
                "closed_at": closed_at,
                "assigned_to": assigned_to,
                "first_response_time": first_response_time,
                "resolution_time": resolution_time,
                "satisfaction_rating": random.randint(1, 5) if status in ["resolved", "closed"] and random.random() > 0.3 else None,
                "tags": [self.fake.word() for _ in range(random.randint(0, 3))],
                "channel": random.choice(["email", "phone", "chat", "social_media", "website"])
            }
            
            tickets.append(ticket)
        
        # Store ticket IDs for reference
        self._store_ids("ticket", [t["ticket_id"] for t in tickets])
        return tickets
    
    def generate_promotions(self, limit: int = 100) -> List[Dict]:
        """Generate promotion and coupon data"""
        if not self.product_ids:
            raise ValueError("Product IDs must be generated before promotions")
            
        promotions = []
        promo_types = ["percentage_discount", "fixed_amount", "buy_one_get_one", "free_shipping"]
        
        for _ in range(limit):
            created_at = self._get_random_date()
            start_date = created_at + timedelta(days=random.randint(1, 30))
            end_date = start_date + timedelta(days=random.randint(7, 90))
            
            # Determine if the promotion targets specific products or categories
            target_type = random.choice(["all", "products", "categories"])
            target_ids = []
            
            if target_type == "products":
                # Target 1-5 products
                num_products = random.randint(1, 5)
                target_ids = random.sample(self.product_ids, min(num_products, len(self.product_ids)))
            elif target_type == "categories":
                # Target 1-3 categories
                num_categories = random.randint(1, 3)
                target_ids = random.sample(self.category_ids, min(num_categories, len(self.category_ids)))
            
            # Generate discount value based on type
            promo_type = random.choice(promo_types)
            value = None
            
            if promo_type == "percentage_discount":
                value = round(random.uniform(5.0, 50.0), 1)  # 5-50% off
            elif promo_type == "fixed_amount":
                value = round(Decimal(str(random.uniform(5.0, 100.0))), 2)  # $5-$100 off
            
            # Generate code
            code = self.fake.bothify(text="???###").upper()
            
            promotion_id = uuid4()
            
            promotion = {
                "promotion_id": promotion_id,
                "name": f"{random.choice(['Summer', 'Winter', 'Spring', 'Fall', 'Holiday', 'Flash', 'Weekend'])} {random.choice(['Sale', 'Special', 'Discount', 'Deal'])}",
                "description": self.fake.paragraph(),
                "code": code,
                "type": promo_type,
                "value": value,
                "minimum_purchase": round(Decimal(str(random.uniform(0.0, 100.0))), 2) if random.random() > 0.5 else None,
                "usage_limit": random.randint(1, 1000) if random.random() > 0.3 else None,
                "usage_count": random.randint(0, 500),
                "start_date": start_date,
                "end_date": end_date,
                "created_at": created_at,
                "updated_at": created_at + timedelta(days=random.randint(0, 10)),
                "is_active": random.random() > 0.2,  # 80% active
                "target_type": target_type,
                "target_ids": target_ids
            }
            
            promotions.append(promotion)
        
        return promotions
    
    def generate_notifications(self, limit: int = 1000) -> List[Dict]:
        """Generate user notification data"""
        if not self.user_ids:
            raise ValueError("User IDs must be generated before notifications")
        
        notifications = []
        notification_types = [
            "order_confirmation", "order_shipped", "order_delivered", 
            "payment_received", "payment_failed", "price_drop", 
            "back_in_stock", "review_request", "support_reply",
            "promotional", "cart_reminder", "wishlist_price_change"
        ]
        
        for _ in range(limit):
            user_id = self._get_random_id("user")
            created_at = self._get_random_date()
            
            notification_type = random.choice(notification_types)
            
            # Generate related IDs based on notification type
            order_id = None
            product_id = None
            
            if notification_type in ["order_confirmation", "order_shipped", "order_delivered"]:
                order_id = self._get_random_id("order") if self.order_ids else None
            elif notification_type in ["payment_received", "payment_failed"]:
                order_id = self._get_random_id("order") if self.order_ids else None
            elif notification_type in ["price_drop", "back_in_stock", "review_request", "wishlist_price_change"]:
                product_id = self._get_random_id("product")
            elif notification_type == "support_reply":
                ticket_id = self._get_random_id("ticket") if self.ticket_ids else None
            
            # Generate title and message based on type
            title = ""
            message = ""
            
            if notification_type == "order_confirmation":
                title = "Order Confirmed"
                message = "Your order has been confirmed and is being processed."
            elif notification_type == "order_shipped":
                title = "Order Shipped"
                message = "Your order has been shipped! Track your package for delivery updates."
            elif notification_type == "order_delivered":
                title = "Order Delivered"
                message = "Your order has been delivered. Enjoy your purchase!"
            elif notification_type == "payment_received":
                title = "Payment Received"
                message = "We've received your payment. Thank you for your purchase!"
            elif notification_type == "payment_failed":
                title = "Payment Failed"
                message = "There was an issue processing your payment. Please update your payment details."
            elif notification_type == "price_drop":
                title = "Price Drop Alert"
                message = "Good news! An item in your wishlist has dropped in price."
            elif notification_type == "back_in_stock":
                title = "Back in Stock"
                message = "An item you were interested in is back in stock!"
            elif notification_type == "review_request":
                title = "Review Your Recent Purchase"
                message = "We'd love to hear your thoughts on your recent purchase."
            elif notification_type == "support_reply":
                title = "Support Ticket Update"
                message = "There's a new update on your support ticket."
            elif notification_type == "promotional":
                title = random.choice(["Special Offer Inside!", "Limited Time Deal", "Exclusive Discount"])
                message = random.choice([
                    "Enjoy 20% off your next purchase with code SPECIAL20.", 
                    "Free shipping on all orders this weekend!", 
                    "Buy one get one free on select items."
                ])
            elif notification_type == "cart_reminder":
                title = "Items in Your Cart"
                message = "Don't forget about the items in your cart! Complete your purchase now."
            elif notification_type == "wishlist_price_change":
                title = "Wishlist Update"
                message = "There's been a price change on an item in your wishlist."
            
            # Determine if notification was read
            read = random.random() > 0.4  # 60% read
            read_at = created_at + timedelta(minutes=random.randint(1, 1440)) if read else None
            
            notification_id = uuid4()
            
            notification = {
                "notification_id": notification_id,
                "user_id": user_id,
                "type": notification_type,
                "title": title,
                "message": message,
                "created_at": created_at,
                "read": read,
                "read_at": read_at,
                "order_id": order_id,
                "product_id": product_id,
                "action_url": f"/orders/{order_id}" if order_id else (f"/products/{product_id}" if product_id else None),
                "icon": random.choice(["bell", "truck", "shopping-bag", "credit-card", "tag", "message"]),
                "priority": random.choice(["low", "normal", "high"])
            }
            
            notifications.append(notification)
        
        return notifications