from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime
from uuid import UUID, uuid4

class UserBase(BaseModel):
    user_id: UUID = Field(default_factory=uuid4)
    email: str
    username: str
    first_name: str
    last_name: str
    phone_number: str
    address: str
    city: str
    state: str
    postal_code: str
    country: str
    created_at: datetime
    updated_at: datetime
    is_active: bool = True
    loyalty_points: int = 0
    preferred_payment_method: Optional[UUID] = None

class UserCreate(UserBase):
    pass

class UserResponse(UserBase):
    pass

class UserList(BaseModel):
    users: List[UserResponse]
    count: int