from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict
from datetime import datetime
from uuid import UUID, uuid4

class FormatParams(BaseModel):
    format: str = "json"
    limit: int = 1000
    seed: Optional[int] = None

class ResponseBase(BaseModel):
    success: bool = True
    count: int
    format: str
    data: Any