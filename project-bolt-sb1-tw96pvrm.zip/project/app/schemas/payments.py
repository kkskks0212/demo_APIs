from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from uuid import UUID, uuid4
from decimal import Decimal

class PaymentBase(BaseModel):
    payment_id: UUID = Field(default_factory=uuid4)
    order_id: UUID
    user_id: UUID
    amount: Decimal
    currency: str = "USD"
    payment_method: str  # credit_card, paypal, apple_pay, etc.
    status: str  # pending, completed, failed, refunded
    created_at: datetime
    updated_at: datetime
    transaction_id: str
    payment_provider: str  # stripe, paypal, etc.
    card_last_four: Optional[str] = None
    billing_address: Optional[str] = None
    billing_city: Optional[str] = None
    billing_state: Optional[str] = None
    billing_postal_code: Optional[str] = None
    billing_country: Optional[str] = None
    refund_id: Optional[UUID] = None
    is_subscription: bool = False
    subscription_id: Optional[UUID] = None

class PaymentCreate(PaymentBase):
    pass

class PaymentResponse(PaymentBase):
    pass

class PaymentList(BaseModel):
    payments: List[PaymentResponse]
    count: int