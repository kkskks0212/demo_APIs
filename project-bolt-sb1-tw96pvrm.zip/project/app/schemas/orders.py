from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from uuid import UUID, uuid4
from decimal import Decimal

class OrderItemBase(BaseModel):
    order_item_id: UUID = Field(default_factory=uuid4)
    order_id: UUID
    product_id: UUID
    quantity: int
    unit_price: Decimal
    discount: Decimal = Decimal("0.00")
    total: Decimal
    is_gift: bool = False
    gift_message: Optional[str] = None

class OrderBase(BaseModel):
    order_id: UUID = Field(default_factory=uuid4)
    user_id: UUID
    status: str  # pending, processing, shipped, delivered, cancelled
    created_at: datetime
    updated_at: datetime
    shipping_address: str
    shipping_city: str
    shipping_state: str
    shipping_postal_code: str
    shipping_country: str
    shipping_method: str
    shipping_cost: Decimal
    subtotal: Decimal
    tax: Decimal
    discount: Decimal = Decimal("0.00")
    total: Decimal
    coupon_code: Optional[str] = None
    notes: Optional[str] = None
    tracking_number: Optional[str] = None
    estimated_delivery: Optional[datetime] = None
    actual_delivery: Optional[datetime] = None
    payment_id: Optional[UUID] = None

class OrderCreate(OrderBase):
    items: List[OrderItemBase]

class OrderResponse(OrderBase):
    items: List[OrderItemBase]

class OrderList(BaseModel):
    orders: List[OrderResponse]
    count: int