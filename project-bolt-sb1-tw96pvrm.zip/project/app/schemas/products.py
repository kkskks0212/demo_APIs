from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from uuid import UUID, uuid4
from decimal import Decimal

class ProductBase(BaseModel):
    product_id: UUID = Field(default_factory=uuid4)
    name: str
    description: str
    sku: str
    price: Decimal
    cost: Decimal
    weight: float
    dimensions: str
    category_id: UUID
    vendor_id: UUID
    created_at: datetime
    updated_at: datetime
    is_active: bool = True
    stock_quantity: int
    tags: List[str] = []
    image_url: Optional[str] = None
    average_rating: float = 0.0
    discount_percentage: float = 0.0

class ProductCreate(ProductBase):
    pass

class ProductResponse(ProductBase):
    pass

class ProductList(BaseModel):
    products: List[ProductResponse]
    count: int