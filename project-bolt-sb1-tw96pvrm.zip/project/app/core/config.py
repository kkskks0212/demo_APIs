from pydantic import BaseModel
from typing import Dict, Any

class Settings(BaseModel):
    APP_NAME: str = "E-Commerce Mock Data API"
    DEBUG: bool = True
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEFAULT_LIMIT: int = 1000
    MAX_LIMIT: int = 10000
    
    # Default date ranges for realistic data
    DATE_START: str = "2023-01-01"
    DATE_END: str = "2023-12-31"
    
    # Output formats
    SUPPORTED_FORMATS: list = ["json", "csv", "xml"]
    DEFAULT_FORMAT: str = "json"

settings = Settings()