import uvicorn
from fastapi import FastAPI, Query, Path, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from app.routers import (
    users, products, orders, payments, 
    shipping, warehouses, vendors, categories,
    reviews, support_tickets, returns, inventory,
    promotions, subscriptions, analytics, carts,
    wishlists, notifications
)
from app.core.config import settings

app = FastAPI(
    title="E-Commerce Mock Data API",
    description="A powerful API that generates realistic mock data for e-commerce ecosystem with logistics and payment integration",
    version="1.0.0",
    docs_url="/",
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include all routers
app.include_router(users.router, prefix="/api/v1", tags=["Users"])
app.include_router(products.router, prefix="/api/v1", tags=["Products"])
app.include_router(categories.router, prefix="/api/v1", tags=["Categories"])
app.include_router(vendors.router, prefix="/api/v1", tags=["Vendors"])
app.include_router(orders.router, prefix="/api/v1", tags=["Orders"])
app.include_router(carts.router, prefix="/api/v1", tags=["Shopping Carts"])
app.include_router(payments.router, prefix="/api/v1", tags=["Payments"])
app.include_router(shipping.router, prefix="/api/v1", tags=["Shipping"])
app.include_router(warehouses.router, prefix="/api/v1", tags=["Warehouses"])
app.include_router(inventory.router, prefix="/api/v1", tags=["Inventory"])
app.include_router(returns.router, prefix="/api/v1", tags=["Returns"])
app.include_router(reviews.router, prefix="/api/v1", tags=["Reviews"])
app.include_router(support_tickets.router, prefix="/api/v1", tags=["Support"])
app.include_router(promotions.router, prefix="/api/v1", tags=["Promotions"])
app.include_router(subscriptions.router, prefix="/api/v1", tags=["Subscriptions"])
app.include_router(wishlists.router, prefix="/api/v1", tags=["Wishlists"])
app.include_router(notifications.router, prefix="/api/v1", tags=["Notifications"])
app.include_router(analytics.router, prefix="/api/v1", tags=["Analytics"])

@app.get("/api/v1/health", tags=["Health"])
async def health_check():
    return {"status": "healthy", "message": "API is running"}

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG
    )